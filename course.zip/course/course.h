/**
 * @file course.h
 * @author Shrey Bawa
 * @date 2022-04-11
 */
#include "student.h"
#include <stdbool.h>
 /**
  *@brief This contains the Struct Course with its name, code, array of students registered and total number of students and the functions for Course
  */
typedef struct _course 
{
  char name[100]; /**< Declaring a character array of size 100. */
  char code[10]; /**< Declaring a character array of size 10. */
  Student *students; /**< An array of students. */
  int total_students; /**< Keeping track of the total number of students in the course. */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


