/**
 * @file student.h
 * @author Shrey Bawa
 * @date 2022-04-11
 */
 /**
  *@brief This contains the struct Student with its submembers first name, last name, id, grades and the number of grades and the functions required for Student
  */
typedef struct _student 
{ 
  char first_name[50]; /**< Declaring a character array of size 50. */
  char last_name[50]; /**< Declaring a character array of size 50. */
  char id[11]; /**< Declaring a character array of size 11. */
  double *grades; /**< Declaring a pointer to a double. */
  int num_grades; /**< Declaring a variable of type int. */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
